/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package productos;

import java.util.Scanner;

/**
 *
 * @author Joshua Sharp
 */
public class Menu {
    
    private static Menu menu;
   
    private Menu() {    
    }
    
    public static Menu getInstance() {
       if (menu == null){
           menu = new Menu();
       }
       return menu;
    }
    
    public void login(){
        String pass = "0";
        Scanner pas = new Scanner(System.in);
        System.out.println("Ingrese su contraseña: ");
        pass=pas.next();
        while (pass != "1234"){
            System.out.println("Contraseña incorrecta. Intente otra vez");
            pass=pas.next();
        }
        System.out.println("Bienvenido al programa");
    }
}
